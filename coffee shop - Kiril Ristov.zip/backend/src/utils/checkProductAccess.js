
export const checkProductAccess = (product, user) => {
  if (user === null) {

  }
}