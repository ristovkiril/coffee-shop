export const navItems = [
  {
    pathname: "/",
    label: "Home",
  },
  {
    pathname: "/ingredients",
    label: "Ingredients",
  },
  {
    pathname: "/default-coffee",
    label: "Default Coffees",
  },
]